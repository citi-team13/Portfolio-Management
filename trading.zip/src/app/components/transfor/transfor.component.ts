import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfor',
  templateUrl: './transfor.component.html',
  styleUrls: ['./transfor.component.scss']
})
export class TransforComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

 
}